#include<iostream>
using namespace std;
int main()
{
	cout<<"Enter a number\n";
	int x;
	cin>>x;
	cout<<"The value:"<<x;
}
