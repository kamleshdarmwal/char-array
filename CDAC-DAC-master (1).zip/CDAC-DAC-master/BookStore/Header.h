#include<fstream>
#include<sstream>

//Header File Start
class BookStore
{
private:
	string bookname, bookauthor;
public:
	void GetData(string bname, string bauth)
	{
		bookname = bname;
		bookauthor = bauth;
	}
	string ShowData()
	{
		return bookname;
	}
	string ShowAuthor()
	{
		return bookauthor;
	}

};
class Store
{
private:
	BookStore books[10];
	BookStore author[10];
public:
	void addBooks(BookStore b)
	{
				WriteData(b.ShowData(), b.ShowAuthor());
	}
	void insertBooks(BookStore b)
	{
		for (int i = 0; i < 10; i++)
		{
			if (books[i].ShowData() == "")
			{
				books[i].GetData(b.ShowData(), b.ShowAuthor());
				break;
			}

		}
	}
	BookStore FindBooks(string name)
	{
		RecieveData();
		for (int i = 0; i < 10; i++)
		{
			if (books[i].ShowData() == name)
			{
				string aname = author[i].ShowAuthor();
				cout << "Book Available Here:" << endl;
				cout << name << " Written By " << aname;
				return books[i];
			}
		}
	}

	BookStore FindBookByAuthor(string name)
	{
		RecieveData();
		for (int i = 0; i < 10; i++)
		{
			if (books[i].ShowAuthor() == name)
			{
				string bname = books[i].ShowData();
				cout << "Book Available Here:" << endl;
				cout << bname << " Written By " << name;
				return books[i];
			}
		}
	}

	BookStore* GetAllBooks()
	{
		RecieveData();
		return books;
	}

	void WriteData(string bname, string bauthor)
	{
		ofstream ost;
		string filename = "Booksdatabase.csv";
		ost.open(filename, ios::app);
		ost << bname << "," << bauthor << "\n";
		ost.close();
	}

	void RecieveData()
	{
		string bname, aname;
		ifstream ist;
		string filename = "Booksdatabase.csv";
		ist.open(filename);
		string line = "";
		int i = 0;
		while (ist)
		{
			getline(ist, bname,',');
			getline(ist, aname, '\n');
	//		cout << "Book Name:" << bname << " & Author name:" << aname<<endl;
			insertBooks(OldBooks(bname, aname));
		}
	}


BookStore OldBooks(string name, string author)
{
	BookStore b1;
	b1.GetData(name, author);
	return b1;
}
};

//Header File End