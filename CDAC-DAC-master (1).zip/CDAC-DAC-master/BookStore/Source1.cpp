#include<iostream>
#include<string>
using namespace std;

//Header File Start
class BookStore
{
private:
	string bookname, bookauthor;
public:
	void GetData(string bname, string bauth)
	{
		bookname = bname;
		bookauthor = bauth;
	}
	string ShowData()
	{
		return bookname;
	}
	string ShowAuthor()
	{
		return bookauthor;
	}

};
class Store
{
private:
	BookStore books[10];
	BookStore author[10];
public:
	void addBooks(BookStore b)
	{
		for (int i = 0; i < 10; i++)
		{
			if (books[i].ShowData() == "")
			{
				books[i].GetData(b.ShowData(),b.ShowAuthor());
				break;
			}

		}
	}

	BookStore FindBooks(string name)
	{
		for (int i = 0; i < 10; i++)
		{
			if (books[i].ShowData() == name)
			{
				string aname = author[i].ShowAuthor();
				cout << "Book Available Here:" << endl;
				cout << name << " Written By " << aname;
				return books[i];
			}
		}
	}

	BookStore FindBookByAuthor(string name)
	{
		for (int i = 0; i < 10; i++)
		{
			if (books[i].ShowAuthor() == name)
			{
				string bname = books[i].ShowData();
				cout << "Book Available Here:"<<endl;
				cout << bname <<" Written By "<<name;
				return books[i];
			}
		}
	}

	BookStore* GetAllBooks()
	{
		return books;
	}

};
//Header File End



BookStore CreateBook(string name, string author)
{
	BookStore b1;
	b1.GetData(name,author);
	return b1;
}

string NewMenu()
{
	string menu = ".............Books Details.............\n";
	menu += "PRESS 1 TO DISPLAY ALL BOOKS \n";
	menu += "PRESS 2 TO SEARCH BOOKS BY BOOKNAME \n";
	menu += "PRESS 3 TO SEARCH BOOKS BY AUTHOR \n";
	menu += "ENTER YOUR CHOICE:";
	return menu;
}

int main()
{
	int i;
	Store padhaku;
	padhaku.addBooks(CreateBook("CPP","ABC"));
	padhaku.addBooks(CreateBook("Java","CDE"));
	padhaku.addBooks(CreateBook("SQL","ABC"));


	cout << NewMenu();
	cin >> i;
	if (i == 1)
	{
		BookStore* AllBooks = padhaku.GetAllBooks();
		for (int i = 0; i < 10; i++)
		{
			cout << (AllBooks[i]).ShowData() <<" ";
			cout << (AllBooks[i]).ShowAuthor() << endl;
		}
	}
	if (i == 2)
	{
		string searchbname;
		cout << "Enter Book Name:";
		cin >> searchbname;
		padhaku.FindBooks(searchbname);
	}
	if (i==3)
	{
		string searchbyname;
		cout << "Enter Book Author Name:";
		cin >> searchbyname;
		padhaku.FindBookByAuthor(searchbyname);
	}
}