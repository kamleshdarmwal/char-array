#include<iostream>
#include<string>
using namespace std;
#include "Header.h"



BookStore CreateBook(string name, string author)
{
	BookStore b1;
	b1.GetData(name, author);
	return b1;
}

BookStore OldBooks(string name, string author)
{
	BookStore b1;
	b1.GetData(name, author);
	return b1;
}

string NewMenu()
{
	string menu = ".............Books Details.............\n";
	menu += "PRESS 1 TO ADD BOOKS \n"; 
	menu += "PRESS 2 TO DISPLAY ALL BOOKS \n";
	menu += "PRESS 3 TO SEARCH BOOKS BY BOOKNAME \n";
	menu += "PRESS 4 TO SEARCH BOOKS BY AUTHOR \n";
	menu += "ENTER YOUR CHOICE:";
	return menu;
}

int main()
{
	int i;
	cout << NewMenu();
	cin >> i;
	string bname, bauthor,choice;
	Store padhaku;
	if (i==1)
	{
		do
		{
			cout << "Enter the book name:";
			cin >> bname;
			cout << "Enter the book author name:";
			cin >> bauthor;
			padhaku.addBooks(CreateBook(bname, bauthor));
			cout << "Enter Y add Another Book:";
			cin >> choice;
		} while (choice == "Y" || choice == "y");
	}
	if (i == 2)
	{
		BookStore* AllBooks = padhaku.GetAllBooks();
		for (int i = 0; i < 10; i++)
		{
			cout << (AllBooks[i]).ShowData() << " ";
			cout << (AllBooks[i]).ShowAuthor() << endl;
		}
	}
	if (i == 3)
	{
		string searchbname;
		cout << "Enter Book Name:";
		cin >> searchbname;
		padhaku.FindBooks(searchbname);
	}
	if (i == 4)
	{
		string searchbyname;
		cout << "Enter Book Author Name:";
		cin >> searchbyname;
		padhaku.FindBookByAuthor(searchbyname);
	}
}