#include <iostream>
using namespace std;
#include <string>
class Student
{
	private:
		int studentId;
		string studentName;
		string studentAddress;
		long studentContact;
		
	public:
	void SetDetails(int id, string name, string address, long phone)
	{
		studentAddress = address;
		studentName = name;
		studentContact = phone;
		studentId = id;
	}
	
	string getDetails(){
		string content = "The name is " + studentName + "The Address is " + studentAddress;
		return content;
	}
	
	string getName(){
		return studentName;
	}
	
	string getAddress(){
		return studentAddress;
	}
	
	long getContact(){
		return studentContact;
	}
	
	int getId(){
		return studentId;
	}
};
