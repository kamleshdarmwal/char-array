#include <iostream>
using namespace std;
#include <string>
#include "Useclass.h"
#include "repository.h"

Student createStudent(int id, string name,string address, long phone){
	Student s;
	s.SetDetails(id, name, address, phone);
	return s;
}

int main() 
{
	int inp;
	char inpu;
	cout<<"What You Want To Do:\n Enter 1 to Add Student\n Enter 2 to Find Student \n Enter 3 to Get All Student \n Enter 4 to Remove Student";

	do
	{
			cout<<"\n Whats your Input:";
			cin>>inp;
			StudentDatabase db;
			if(inp==1)
			{
				int newid;
				string newname,newaddress;
				long cno;
				cout<<"\nEnter Id,\nName,\nAddress,\nPhone Number \n";
				cin>>newid>>newname>>newaddress>>cno;
				db.AddNewStudent(createStudent(newid,newname,newaddress,cno));
				cout<<"Student Added";
			}
			if(inp==2)
			{
				int newid;
				cout<<"Enter ID to search:";
				cin>>newid;
				Student found = db.FindStudent(newid);
				cout<<found.getDetails()<<endl;	
			}
			if(inp==3)
			{
				Student* allStudents = db.GetAllStudents();
				for(int i=0; i < 3; i++)
				{
					cout<<(allStudents[i]).getName()<<endl;
				}
			}
			if(inp==4)
			{
				int newid;
				cout<<"Enter ID to Delete:";
				cin>>newid;
				db.DeleteStudent(newid);	
			}
			cout<<"\n Enter Y to Continue:";
			cin>>inpu;
	}
	while(inpu=='Y'||inpu=='y');

	return 0;
}


