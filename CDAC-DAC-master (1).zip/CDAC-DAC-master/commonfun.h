void charArrExample()
{
	char strcontent[100];
	strcontent[0]='A';
	strcontent[1]='P';
	strcontent[2]='P';
	strcontent[3]='L';
	strcontent[4]='E';
	
strcat(strcontent," keeps the doctor away");
cout<<strcontent;
}
