#include<iostream>
using namespace std;
#include<cstring>
#include<string>
#include "commonfun.h"
int main()
{
	charArrExample();
}
